/*jshint node:true */
/*global describe, it */
'use strict';

var assert = require('assert');
var HasJS = require('../lib/HasJS.js');

describe('HasJS', function() {
    describe('init', function() {
        it('should', function() {
            // TODO: test this
            assert.ok(true);
        });
    });
});
